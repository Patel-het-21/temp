package com.employeedatamanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDataManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDataManagementApplication.class, args);
	}

}
