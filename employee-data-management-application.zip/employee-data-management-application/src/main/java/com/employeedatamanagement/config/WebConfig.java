package com.employeedatamanagement.config;

public class WebConfig {

}
