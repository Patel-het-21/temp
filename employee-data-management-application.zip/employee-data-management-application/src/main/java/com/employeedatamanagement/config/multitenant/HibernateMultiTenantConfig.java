package com.employeedatamanagement.config.multitenant;

public class HibernateMultiTenantConfig {

}
