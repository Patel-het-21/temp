package com.employeedatamanagement.config.multitenant;

public class TenantIdentifierResolver {

}
