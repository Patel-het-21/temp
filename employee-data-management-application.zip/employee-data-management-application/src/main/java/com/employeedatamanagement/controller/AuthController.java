package com.employeedatamanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.employeedatamanagement.dto.LoginRequestDto;
import com.employeedatamanagement.dto.RegisterRequestDto;
import com.employeedatamanagement.dto.UserResponseDto;
import com.employeedatamanagement.entity.User;
import com.employeedatamanagement.service.AuthService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/auth")
@Validated
@CrossOrigin(
	    origins = {
	        "http://localhost:4200",
	        "http://localhost:9090"
	    },
	    allowCredentials = "true"
	)public class AuthController {

	private final AuthService authService;

	@Autowired
	public AuthController(AuthService authService) {
		this.authService = authService;
	}

	@PostMapping("/register")
	public ResponseEntity<UserResponseDto> register(@Valid @RequestBody RegisterRequestDto dto) {
		User user = authService.register(dto);
		//return ResponseEntity.ok(user);
		return ResponseEntity.ok(
	            new UserResponseDto(user.getId(), user.getCompanyName(), user.getEmail())
	        );
	}

	@PostMapping("/login")
	public ResponseEntity<UserResponseDto> login(@Valid @RequestBody LoginRequestDto dto) {
		User user = authService.login(dto);
		//return ResponseEntity.ok("Login Success");
		return ResponseEntity.ok(
	            new UserResponseDto(user.getId(), user.getCompanyName(), user.getEmail())
	        );
	}

	@PostMapping("/logout")
	public ResponseEntity<String> logout() {
		authService.logout();
		//return ResponseEntity.ok().build();
		return ResponseEntity.ok("Logged out successfully");
	}

}