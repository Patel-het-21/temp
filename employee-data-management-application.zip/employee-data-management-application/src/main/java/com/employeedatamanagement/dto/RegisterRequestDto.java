package com.employeedatamanagement.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequestDto {

	@NotBlank
	private String companyName;

	@NotBlank
	@Size(min = 8, message = "Password must be at least 8 characters")
	private String password;

	@Email
	@NotBlank
	private String email;

}