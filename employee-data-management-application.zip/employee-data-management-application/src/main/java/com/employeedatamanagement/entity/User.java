package com.employeedatamanagement.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

/**
 * @author Het Patel
 * @since 27/01/26
 * 
 * Entity representing a system user.
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class User {

	/**
	 * Primary key of the users table.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	/**
	 * Unique companyname used for authentication.
	 */
	@Column(name = "companyname", unique = true, nullable = false)
	String companyName;

	/**
	 * Encrypted password of the user.
	 */
	@Column(nullable = false)
	String password;

	/**
	 * Unique email address of the user.
	 */
	@Column(unique = true, nullable = false)
	String email;

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
	List<Employee> employees;

}