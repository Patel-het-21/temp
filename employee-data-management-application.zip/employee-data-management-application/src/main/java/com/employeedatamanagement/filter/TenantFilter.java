package com.employeedatamanagement.filter;

import java.io.IOException;

import com.employeedatamanagement.config.multitenant.TenantContext;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class TenantFilter extends HttpFilter{

	@Override
	protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
		/*
		 * Read tenant from request header
		 */
		String tenantId = request.getHeader("X-TenantID");

		if (tenantId == null || tenantId.isEmpty()) {
			tenantId = "default";
		}
		/*
		 * Set tenant for current request
		 */
		TenantContext.setTenantId(tenantId);

		try {
			/*
			 * Continue request processing
			 */
			chain.doFilter(request, response);
		} finally {
			/*
			 * Clear tenant after request is processed
			 */
			TenantContext.clear();
		}
	}

}