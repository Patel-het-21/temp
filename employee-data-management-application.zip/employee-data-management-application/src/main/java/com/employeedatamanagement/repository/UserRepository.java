package com.employeedatamanagement.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employeedatamanagement.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByCompanyName(String companyName);

	Optional<User> findByEmail(String email);

	boolean existsByCompanyName(String companyName);

	boolean existsByEmail(String email);

}