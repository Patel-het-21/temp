package com.employeedatamanagement.service;

import com.employeedatamanagement.dto.LoginRequestDto;
import com.employeedatamanagement.dto.RegisterRequestDto;
import com.employeedatamanagement.entity.User;

public interface AuthService {

	User register(RegisterRequestDto dto);

	User login(LoginRequestDto dto);

	void logout();

}