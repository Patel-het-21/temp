package com.employeedatamanagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeedatamanagement.dto.LoginRequestDto;
import com.employeedatamanagement.dto.RegisterRequestDto;
import com.employeedatamanagement.entity.User;
import com.employeedatamanagement.repository.UserRepository;
import com.employeedatamanagement.service.AuthService;

import jakarta.servlet.http.HttpSession;

@Service
public class AuthServiceImpl implements AuthService {

	private final UserRepository userRepository;
	private final HttpSession session;

	@Autowired
	public AuthServiceImpl(UserRepository userRepository, HttpSession session) {
		this.userRepository = userRepository;
		this.session = session;
	}

	@Override
	public User register(RegisterRequestDto dto) {
		if (userRepository.existsByEmail(dto.getEmail())) {
			throw new IllegalArgumentException("Email already registered");
		}
		if (userRepository.existsByCompanyName(dto.getCompanyName())) {
			throw new IllegalArgumentException("Company Name already taken");
		}

		User user = new User();
		user.setCompanyName(dto.getCompanyName());
		user.setEmail(dto.getEmail());
		user.setPassword(dto.getPassword());

		return userRepository.save(user);
	}

	@Override
	public User login(LoginRequestDto dto) {

		User user = userRepository.findByEmail(dto.getEmail()).orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));

		if (!user.getPassword().equals(dto.getPassword())) {
			throw new IllegalArgumentException("Invalid email or password");
		}
		// store user in session
		session.setAttribute("LOGGED_IN_USER", user);
		return user;
	}

	@Override
	public void logout() {
		session.invalidate();
	}

}